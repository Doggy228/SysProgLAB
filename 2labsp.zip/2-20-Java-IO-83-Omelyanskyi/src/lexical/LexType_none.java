package edu.kpi.io8322.sysprog.lab.lexical;

public class LexType_none extends LexType {
    public LexTypeEnum getType(){
        return LexTypeEnum.NONE;
    }
}
