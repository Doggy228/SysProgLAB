package edu.kpi.io8322.sysprog.lab.lexical;

public class LexType_return extends LexType_keyword {
    public LexTypeEnum getType(){
        return LexTypeEnum.RETURN;
    }
}
