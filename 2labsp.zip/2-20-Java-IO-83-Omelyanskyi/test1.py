def main():
    return not 12345