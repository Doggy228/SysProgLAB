def main():
    return +0x2F