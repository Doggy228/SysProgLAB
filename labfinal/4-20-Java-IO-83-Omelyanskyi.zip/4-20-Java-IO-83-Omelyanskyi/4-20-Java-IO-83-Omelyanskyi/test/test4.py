def main():
    a = 5
    b = 3 if 7 5 
    return b