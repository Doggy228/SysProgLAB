def main():
    a = '7'
    b = 3 if a<'6' else a+"52"
    b = b-0x2F if 100<b else not b
    return b