def main():
    a = 5
    b = 3 if a<3 else 7 if a<2 else 9 
    return b