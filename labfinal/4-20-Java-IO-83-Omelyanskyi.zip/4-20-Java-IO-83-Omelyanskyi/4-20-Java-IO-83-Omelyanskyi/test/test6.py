def main():
    a = 5
    5 if a<7 else 5 
    return b