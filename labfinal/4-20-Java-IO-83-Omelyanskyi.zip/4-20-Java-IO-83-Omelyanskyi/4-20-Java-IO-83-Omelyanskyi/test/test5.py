def main():
    a = 5
    b = if 7 5 
    return b