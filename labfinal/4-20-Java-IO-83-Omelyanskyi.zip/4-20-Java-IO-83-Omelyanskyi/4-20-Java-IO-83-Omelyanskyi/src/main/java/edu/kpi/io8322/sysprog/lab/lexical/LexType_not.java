package edu.kpi.io8322.sysprog.lab.lexical;

public class LexType_not extends LexType_keyword {
    public LexTypeEnum getType(){
        return LexTypeEnum.NOT;
    }
}
