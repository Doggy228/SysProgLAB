package edu.kpi.io8322.sysprog.lab.lexical;

public class LexType_constint extends LexType_const {
    public LexTypeEnum getType(){
        return LexTypeEnum.CONSTINT;
    }
}
