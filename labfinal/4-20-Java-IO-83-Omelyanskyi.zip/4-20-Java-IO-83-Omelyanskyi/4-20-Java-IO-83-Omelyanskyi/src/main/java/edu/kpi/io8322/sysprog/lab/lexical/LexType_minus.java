package edu.kpi.io8322.sysprog.lab.lexical;

public class LexType_minus extends LexType_symb {
    public LexTypeEnum getType(){
        return LexTypeEnum.MINUS;
    }
}
