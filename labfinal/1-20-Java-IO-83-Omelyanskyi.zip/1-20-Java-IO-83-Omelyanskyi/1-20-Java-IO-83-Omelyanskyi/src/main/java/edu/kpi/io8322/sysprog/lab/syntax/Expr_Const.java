package edu.kpi.io8322.sysprog.lab.syntax;

public abstract class Expr_Const extends Expr {
    public Expr_Const(int row, int col){
        super(row, col);
    }
}
