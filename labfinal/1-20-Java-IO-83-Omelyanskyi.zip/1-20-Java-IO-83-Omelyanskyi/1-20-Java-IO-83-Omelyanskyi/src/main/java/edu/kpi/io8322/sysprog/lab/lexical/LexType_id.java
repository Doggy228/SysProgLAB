package edu.kpi.io8322.sysprog.lab.lexical;

public class LexType_id extends LexType {
    public LexTypeEnum getType(){
        return LexTypeEnum.ID;
    }
}
