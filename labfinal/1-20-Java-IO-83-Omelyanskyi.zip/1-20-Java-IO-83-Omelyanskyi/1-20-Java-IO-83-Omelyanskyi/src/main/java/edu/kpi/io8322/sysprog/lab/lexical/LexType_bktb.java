package edu.kpi.io8322.sysprog.lab.lexical;

public class LexType_bktb extends LexType_symb {
    public LexTypeEnum getType(){
        return LexTypeEnum.BKTB;
    }
}
