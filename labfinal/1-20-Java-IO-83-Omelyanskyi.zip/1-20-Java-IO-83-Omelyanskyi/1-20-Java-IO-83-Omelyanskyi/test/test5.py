def main():
    return1 'T'