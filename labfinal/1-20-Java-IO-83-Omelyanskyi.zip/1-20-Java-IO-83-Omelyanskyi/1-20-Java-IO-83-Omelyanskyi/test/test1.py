def main():
    return 12345