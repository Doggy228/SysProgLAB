def main():
    return 12q