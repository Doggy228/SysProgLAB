def main():
    return 'T'