def main():
    return 0xF00000001