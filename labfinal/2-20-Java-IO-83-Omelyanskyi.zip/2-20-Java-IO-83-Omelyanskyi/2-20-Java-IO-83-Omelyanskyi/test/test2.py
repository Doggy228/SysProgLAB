def main():
    return not 0x0