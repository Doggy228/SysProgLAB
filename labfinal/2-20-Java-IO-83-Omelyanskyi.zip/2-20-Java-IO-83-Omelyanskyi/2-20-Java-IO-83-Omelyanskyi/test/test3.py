def main():
    return 0x2F+'B'+(25+3)+12