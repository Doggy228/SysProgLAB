def main():
    return 2 not 0x2F