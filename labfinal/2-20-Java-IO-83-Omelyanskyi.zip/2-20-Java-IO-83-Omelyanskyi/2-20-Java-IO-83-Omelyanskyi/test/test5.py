def main():
    return 2++0x2F