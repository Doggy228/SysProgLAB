def main():
    1a = 123
    return a-28