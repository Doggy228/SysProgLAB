def main():
    a = 123
    b
    return a-28