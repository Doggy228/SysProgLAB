def main():
    a = "a128"
    return a-28