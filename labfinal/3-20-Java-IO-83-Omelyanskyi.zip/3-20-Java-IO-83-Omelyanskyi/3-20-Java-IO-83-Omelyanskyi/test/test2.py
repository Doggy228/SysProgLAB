def main():
    a = 5+3
    b = a-2
    c = b+(27-b)-a
    return a+b+c-1