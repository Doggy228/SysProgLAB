def main():
    a = "128"
    return a-b