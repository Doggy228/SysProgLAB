def main():
    a = "128"
    return a-28<101