def main():
    a = "26"+('3'-'2')-1-0x1A
    b = not a
    return 0<b