package edu.kpi.io8322.sysprog.lab.lexical;

public abstract class LexType_const extends LexType {
}
