package edu.kpi.io8322.sysprog.lab.lexical;

public enum LexTypeEnum {
    NONE, BLOCKINDENT, SYMB, BKTB, BKTE, COLON, QUOTE1, QUOTE2, KEYWORD, DEF, RETURN, CONST, CONSTINT, CONSTCHAR, ID,
    NOT, PLUS,
    EQUAL, MINUS, LESS, CONSTSTR;
}
