package edu.kpi.io8322.sysprog.lab.lexical;

public class LexType_equal extends LexType_symb {
    public LexTypeEnum getType(){
        return LexTypeEnum.EQUAL;
    }
}
